/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carrace;

import java.util.Random;

/**
 *
 * @author Iron Golem
 */
public class carClass {
    private String make;
    private String model;
    private int year;
    private int speed;
    
    public carClass(String aMake, String aModel, int aYear, int aSpeed){
        this.make = aMake;
        this.model = aModel;
        this.year = aYear;
        this.speed = aSpeed;
    }

    public String getMake() {
        return make;
    }

    public String getModel() {
        return model;
    }

    public int getYear() {
        return year;
    }

    public int getSpeed() {
        return speed;
    }

    public void setMake(String make) {
        this.make = make;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public void setSpeed(int speed) {
        this.speed = speed;
    }
    
    public String toString(){
        return "Make: " + make + " Model: " + model + " Year: " + year + " Speed: " + speed;
    }
    
    public void accelerate(){
        Random rand = new Random();
        speed = speed + rand.nextInt(70 - 5 + 1) +5;
    }
    
    public void brake() {
        Random rand = new Random();
        speed = speed - rand.nextInt(30 - 5 + 1) +5;
    }
}
