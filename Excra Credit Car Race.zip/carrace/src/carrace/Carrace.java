/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package carrace;
import java.io.*;
import java.util.Scanner;
/**
 *
 * @author Iron Golem
 */
public class Carrace {
    
    public static carClass[] carArray1;
    public static carClass[] carArray2;
            
    public static void main(String[] args) throws IOException {
        createArrayOfCars();
        raceArrayofCars();
    }
    public static void createArrayOfCars()throws IOException {
        int array1Size;
        String make, model;
        int year, speed;
        
        File aFile1 = new File("WinnerCarSet1.txt");
        Scanner inFile1 = new Scanner(aFile1); //opens file
        
        array1Size = inFile1.nextInt();
        carArray1 = new carClass[array1Size];
        
        int i = 0;
        carClass aCar;
        while(inFile1.hasNext() && i < carArray1.length) {
            year = inFile1.nextInt();
            make = inFile1.next();
            model = inFile1.next();
            speed = inFile1.nextInt();
            aCar = new carClass(make, model, year, speed);
            carArray1[i] = aCar;
            i++;
        }
        
        for(int j = 0; j < carArray1.length; j++) {
            System.out.println(carArray1[j]);
        }
        
        //close file
        inFile1.close();
        
        File aFile2 = new File("loserCarSet2.txt");
        Scanner inFile2 = new Scanner(aFile2); //opens file
        
        int array2Size;
        array2Size = inFile2.nextInt();
        carArray2 = new carClass[array1Size];
        
        i = 0;
        while(inFile2.hasNext() && i < carArray2.length) {
            year = inFile2.nextInt();
            make = inFile2.next();
            model = inFile2.next();
            speed = inFile2.nextInt();
            aCar = new carClass(make, model, year, speed);
            carArray2[i] = aCar;
            i++;
        }
        
        for(int j = 0; j < carArray2.length; j++) {
            System.out.println(carArray2[j]);
        }
        //close file
        inFile2.close();
    }
    public static void raceArrayofCars() throws IOException {
        
        for(int j = 0; j < carArray1.length; j++) {
            for( int i = 0; i < 5; i++){
                carArray1[j].accelerate();
                carArray2[j].accelerate();

                carArray1[j].brake();
                carArray2[j].brake();
            }

            if (carArray1[j].getSpeed() > carArray2[j].getSpeed()){
                System.out.println("The winner is " + carArray1[j]);
            }
            else if (carArray1[j].getSpeed() == carArray2[j].getSpeed()) {
                    System.out.println("its a tie!");
            }
            else {
                System.out.println("The winner is "+ carArray2[j]);
            }
        }
    }
}
